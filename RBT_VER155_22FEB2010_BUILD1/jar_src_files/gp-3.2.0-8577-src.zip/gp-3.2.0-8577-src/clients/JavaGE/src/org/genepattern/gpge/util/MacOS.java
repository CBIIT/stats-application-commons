/*
  The Broad Institute
  SOFTWARE COPYRIGHT NOTICE AGREEMENT
  This software and its documentation are copyright (2003-2008) by the
  Broad Institute/Massachusetts Institute of Technology. All rights are
  reserved.

  This software is supplied without any warranty or guaranteed support
  whatsoever. Neither the Broad Institute nor MIT can be responsible for its
  use, misuse, or functionality.
*/


package org.genepattern.gpge.util;

import java.io.*;
import java.net.*;
/**
 *  Utilities for Mac OS X specific functions
 *
 * @author    Joshua Gould
 */
public class MacOS {
   private static java.lang.reflect.Method selectFileMethod;
   private static Object NSWorkspace;


   private MacOS() { }


   /**
    *  Selects the file specified by <tt>file</tt> in a new file viewer is
    *  opened. Returns true if the file is successfully selected, false
    *  otherwise.
    *
    * @param  file  the file to open
    * @return       <tt>true</tt> if the file is opened successfully, <tt>false
    *      </tt> otherwise
    */
   public static boolean showFileInFinder(File file) {
      try {
         if(file.exists()) {
            String path = file.getCanonicalPath();

            Object opened = selectFileMethod.invoke(NSWorkspace, new Object[]{path, path});
            if(opened instanceof Boolean) {
               return ((Boolean) opened).booleanValue();
            }
         }
         return false;
      } catch(Throwable t) {
         return false;
      }
   }

   static {
      try {
         Class NSWorkspaceClass = null;
         if(new File("/System/Library/Java/com/apple/cocoa/application/NSWorkspace.class").exists()) {
            ClassLoader classLoader = new URLClassLoader(new URL[]{new File("/System/Library/Java").toURL()});
            NSWorkspaceClass = Class.forName("com.apple.cocoa.application.NSWorkspace", true, classLoader);
         } else {
            NSWorkspaceClass = Class.forName("com.apple.cocoa.application.NSWorkspace");
         }

         java.lang.reflect.Method sharedWorkspaceMethod = NSWorkspaceClass.getMethod("sharedWorkspace",
               null);
         NSWorkspace = sharedWorkspaceMethod.invoke(null, null);

         selectFileMethod = NSWorkspace.getClass().getMethod("selectFile",
               new Class[]{String.class, String.class});
      } catch(Throwable t) {

      }
   }
}

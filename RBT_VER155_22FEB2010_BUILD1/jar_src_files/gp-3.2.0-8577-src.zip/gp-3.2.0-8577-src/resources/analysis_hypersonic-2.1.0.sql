
update props set value='2.1.0' where key='schemaVersion';

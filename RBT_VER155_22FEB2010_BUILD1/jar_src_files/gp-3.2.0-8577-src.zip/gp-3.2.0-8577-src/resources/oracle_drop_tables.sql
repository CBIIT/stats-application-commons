/* remove all of the data from the tables */
delete from GPPORTAL.SYSTEM_MESSAGE;
delete from GPPORTAL.ANALYSIS_JOB;
delete from GPPORTAL.TASK_MASTER;
delete from GPPORTAL.SUITE_MODULES;
delete from GPPORTAL.SUITE;
delete from GPPORTAL.LSIDS;
delete from GPPORTAL.JOB_COMPLETION_EVENT;
delete from GPPORTAL.GP_USER_PROP;
delete from GPPORTAL.GP_USER;


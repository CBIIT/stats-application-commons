update props set value='1.4.1' where key='schemaVersion';

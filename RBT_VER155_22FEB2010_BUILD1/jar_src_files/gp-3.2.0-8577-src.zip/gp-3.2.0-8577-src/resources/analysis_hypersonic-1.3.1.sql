update props set value='1.3.1' where key='schemaVersion';

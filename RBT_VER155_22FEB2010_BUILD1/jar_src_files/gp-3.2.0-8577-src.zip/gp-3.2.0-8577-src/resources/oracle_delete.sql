delete from ANALYSIS_JOB
go
delete from TASK_MASTER
go
delete from LSIDS
go
delete from JOB_COMPLETION_EVENT
go
delete from SUITE_MODULES
go
delete from SUITE
go
delete from GP_USER_PROP
go 
delete from GP_USER

/*
 The Broad Institute
 SOFTWARE COPYRIGHT NOTICE AGREEMENT
 This software and its documentation are copyright (2003-2009) by the
 Broad Institute/Massachusetts Institute of Technology. All rights are
 reserved.
 
 This software is supplied without any warranty or guaranteed support
 whatsoever. Neither the Broad Institute nor MIT can be responsible for its
 use, misuse, or functionality.
 */

package org.genepattern.server.handler;

import org.apache.log4j.Logger;
import org.genepattern.server.AnalysisTask;
import org.genepattern.server.TaskIDNotFoundException;
import org.genepattern.server.database.HibernateUtil;
import org.genepattern.server.webservice.server.dao.AnalysisDAO;
import org.genepattern.webservice.JobInfo;
import org.genepattern.webservice.OmnigeneException;
import org.genepattern.webservice.ParameterFormatConverter;
import org.genepattern.webservice.ParameterInfo;

/**
 * AddNewJobHandler to submit a job request and get back <CODE>JobInfo</CODE>
 *
 * @author rajesh kuttan
 * @version 1.0
 */

public class AddNewJobHandler extends RequestHandler {
    private static Logger log = Logger.getLogger(AddNewJobHandler.class);
    protected int taskID = 1;
    protected String parameter_info = "";
    protected ParameterInfo[] parameterInfoArray = null;
    protected String userID;
    
    protected int parentJobID;
    
    protected boolean hasParent = false;
    
    /** Creates new GetAvailableTasksHandler */
    public AddNewJobHandler() {
        super();
    }
    
    /**
     * Constructor with taskID, ParameterInfo[]
     *
     * @param taskID
     *            taskID from <CODE>TaskInfo</CODE>
     * @param parameterInfoArray
     *            <CODE>ParameterInfo</CODE>
     */
    public AddNewJobHandler(int taskID, String userID, ParameterInfo[] parameterInfoArray) {
        this.taskID = taskID;
        this.userID = userID;
        this.parameterInfoArray = parameterInfoArray;
    }
    
    /**
     * Constructor with taskID, ParameterInfo[] and parentJobID
     *
     * @param taskID
     *            taskID from <CODE>TaskInfo</CODE>
     * @param parameterInfoArray
     *            <CODE>ParameterInfo</CODE>
     * @param parentJobID
     *            the parent job number
     */
    public AddNewJobHandler(int taskID, String userID, ParameterInfo[] parameterInfoArray, int parentJobID) {
        this.taskID = taskID;
        this.userID = userID;
        this.parameterInfoArray = parameterInfoArray;
        this.parentJobID = parentJobID;
        hasParent = true;
    }
    
    /**
     * Creates job. Call this fun. if you need JobInfo object
     *
     * @throws TaskIDNotFoundException
     *             TaskIDNotFoundException
     * @throws OmnigeneException
     * @return <CODE>JobIndo</CODE>
     */
    public JobInfo executeRequest() throws OmnigeneException, TaskIDNotFoundException {
        JobInfo ji = null;
        try {
            if(log.isDebugEnabled()) {
                log.debug("executeRequest");
            }
            ParameterFormatConverter pfc = new ParameterFormatConverter();
            parameter_info = pfc.getJaxbString(parameterInfoArray);
            
            // Insert job record.  Transaction is committed to avoid deadlock.
            HibernateUtil.beginTransaction();
            AnalysisDAO ds = new AnalysisDAO();
            // Invoke EJB function
            if (hasParent) {
                ji = ds.addNewJob(taskID, userID, parameter_info, parentJobID);
            } 
            else {
                ji = ds.addNewJob(taskID, userID, parameter_info, -1);
            }

            // Checking for null
            if (ji == null) {
                HibernateUtil.rollbackTransaction();
                throw new OmnigeneException(
                    "AddNewJobRequest:executeRequest Operation failed, null value returned for JobInfo");
            }
            
            HibernateUtil.commitTransaction();
            
            if(log.isDebugEnabled()) {
                log.debug("Waking up job queue");
            }
            AnalysisTask.getInstance().wakeupJobQueue();
            
            // Reparse parameter_info before sending to client
            ji.setParameterInfoArray(pfc.getParameterInfoArray(parameter_info));
        } 
        catch (TaskIDNotFoundException taskEx) {
            HibernateUtil.rollbackTransaction();
            log.error("AddNewJob(executeRequest) " + taskID, taskEx);
            throw taskEx;
        } 
        catch (Exception ex) {
            HibernateUtil.rollbackTransaction();
            log.error("AddNewJob(executeRequest): Error ",  ex);
            throw new OmnigeneException(ex.getMessage());
        }
        
        return ji;
    }
}

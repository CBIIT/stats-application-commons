function testListMethods(obj)
    
    listMethods(obj.server);
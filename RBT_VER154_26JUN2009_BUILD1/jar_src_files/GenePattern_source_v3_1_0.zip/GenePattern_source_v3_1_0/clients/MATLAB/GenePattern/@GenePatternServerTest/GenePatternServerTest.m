function obj = GenePatternServerTest(GPClient)

obj.server = GPClient;

obj = class(obj, 'GenePatternServerTest');

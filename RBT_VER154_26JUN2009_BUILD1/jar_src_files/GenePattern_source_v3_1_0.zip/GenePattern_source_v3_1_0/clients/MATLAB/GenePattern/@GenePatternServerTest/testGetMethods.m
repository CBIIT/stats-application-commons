function testGetMethods(obj)

    am = getMethods(obj.server);
    size(am);
    
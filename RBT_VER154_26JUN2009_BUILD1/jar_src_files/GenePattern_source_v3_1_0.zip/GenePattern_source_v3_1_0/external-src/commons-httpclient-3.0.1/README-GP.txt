when using httpclient in an applet, commons-logging causes the applet to fail. The source code in this directory replaces
the required logging classes with dummy classes.